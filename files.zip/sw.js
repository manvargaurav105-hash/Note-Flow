// NoteFlow Service Worker
// Ye file app ko offline bhi kaam karata hai! 🔥

const CACHE_NAME = 'noteflow-v1';
const FILES_TO_CACHE = [
  '/noteflow/NoteFlow_App.html',
  '/noteflow/manifest.json',
];

// Install — files cache mein save karo
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('NoteFlow: Files cache ho gayi!');
      return cache.addAll(FILES_TO_CACHE);
    })
  );
  self.skipWaiting();
});

// Activate — purana cache delete karo
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keyList) =>
      Promise.all(
        keyList.map((key) => {
          if (key !== CACHE_NAME) {
            console.log('NoteFlow: Purana cache delete hua', key);
            return caches.delete(key);
          }
        })
      )
    )
  );
  self.clients.claim();
});

// Fetch — pehle cache se do, nahi toh internet se lo
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      if (response) {
        return response; // Cache se mila!
      }
      return fetch(event.request); // Internet se lo
    })
  );
});
